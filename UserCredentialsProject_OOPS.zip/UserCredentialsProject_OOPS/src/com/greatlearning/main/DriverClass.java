package com.greatlearning.main;

import java.util.Scanner;

import com.greatlearning.model.Employee;

import com.greatlearning.service.Credentialservice;

public class DriverClass {

	public static void main(String[] args) {
		
		Employee employee = new Employee ("SaravanaKumar", "Sabanayagam");
		
		Credentialservice credentials = new Credentialservice ();
		
		String generatedEmail;
		char [] generatePassword;
		
		System.out.println("Welcome to company abc !!!");
		
		System.out.println();
		
		System.out.println("Please enter the department from the following");
		
		System.out.println("1.Technical");
		
		System.out.println("2.Admin");
		
		System.out.println("3.Human Resource");
		
		System.out.println("4.Legal");
		
		Scanner sc = new Scanner (System.in);
		
		int option = sc.nextInt();
		
		if (option == 1) {
			
			generatedEmail = credentials.generatedEmailaddress(employee.getFirstname().toLowerCase(),employee.getLastname().toLowerCase(), "tech");
			generatePassword = credentials.generatedPassword();
			credentials.showcredentials(employee , generatedEmail, generatePassword);
		
		}
		
		else if (option == 2) {
			
			generatedEmail = credentials.generatedEmailaddress(employee.getFirstname().toLowerCase(),employee.getLastname().toLowerCase(), "admin");
			generatePassword = credentials.generatedPassword();
			credentials.showcredentials(employee , generatedEmail, generatePassword);
		
		}
		
		else if (option == 3){
			
			generatedEmail = credentials.generatedEmailaddress(employee.getFirstname().toLowerCase(),employee.getLastname().toLowerCase(), "hr");
			generatePassword = credentials.generatedPassword();
			credentials.showcredentials(employee , generatedEmail, generatePassword);
		
		}
		
		else if (option == 4){
			
			generatedEmail = credentials.generatedEmailaddress(employee.getFirstname().toLowerCase(),employee.getLastname().toLowerCase(), "legal");
			generatePassword = credentials.generatedPassword();
			credentials.showcredentials(employee , generatedEmail, generatePassword);
		
		}
		
		else {
			
			System.out.println("Please enter a valid option");
			
		}
		
		sc.close();

	}

}