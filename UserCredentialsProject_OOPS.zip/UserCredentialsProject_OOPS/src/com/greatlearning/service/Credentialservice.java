package com.greatlearning.service;

import java.util.Random;

import com.greatlearning.model.Employee;

public class Credentialservice {
	
	public char[] generatedPassword()
	{
		char[] password = new char[8];
		
		Random random = new Random();
		
		String caps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String small = "abcdefghijklmnopqrstuvwxyz";
		String num = "0123456789";
		String special = "!@#$%^&*";
		
		password[0] = caps.charAt(random.nextInt(caps.length()));
		password[1] = small.charAt(random.nextInt(small.length()));
		password[2] = num.charAt(random.nextInt(num.length()));
		password[3] = special.charAt(random.nextInt(special.length()));
		password[4] = caps.charAt(random.nextInt(caps.length()));
		password[5] = small.charAt(random.nextInt(small.length()));
		password[6] = num.charAt(random.nextInt(num.length()));
		password[7] = special.charAt(random.nextInt(special.length()));	
		
	return password;
   
}

    public String generatedEmailaddress(String firstname , String lastname, String department)
    {
    	return firstname+lastname+"@"+department+".abc.com";
    }
    
    public void showcredentials(Employee employee, String email, char[] generatedPassword)
    
    {
    
    	System.out.println("Dear " +employee.getFirstname() + " your generated credentials are as follows:" );
    	System.out.println("Email   ----->" + email);
    	System.out.println("Password---->" + generatedPassword);
    	
    }
    
}
    
    
    
    